import { SEARCH_ENGINES } from '../constants/searchEngines';
import { SearchEngineId } from '../types/browser';

/**
 * Checks if a string is a valid URL or domain
 */
export function isLikelyUrl(input: string): boolean {
  const trimmed = input.trim();
  if (trimmed.startsWith('vortex://') || trimmed.startsWith('about:')) {
    return true;
  }
  if (/^https?:\/\//i.test(trimmed)) {
    return true;
  }
  // Check if it's like "github.com", "google.com/search", "localhost:3000"
  if (/^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+(:\d+)?(\/.*)?$/i.test(trimmed)) {
    return true;
  }
  if (/^localhost(:\d+)?(\/.*)?$/i.test(trimmed)) {
    return true;
  }
  return false;
}

/**
 * Normalizes input: if it's a URL, returns full https:// url;
 * if it's a search term, returns search engine query URL
 */
export function resolveNavigationUrl(input: string, engineId: SearchEngineId = 'duckduckgo'): string {
  const trimmed = input.trim();
  if (!trimmed) {
    return 'vortex://home';
  }

  if (trimmed === 'vortex://home' || trimmed === 'vortex://newtab' || trimmed === 'about:blank') {
    return 'vortex://home';
  }

  if (trimmed.startsWith('vortex://')) {
    return trimmed;
  }

  if (isLikelyUrl(trimmed)) {
    if (/^https?:\/\//i.test(trimmed)) {
      return trimmed;
    }
    return `https://${trimmed}`;
  }

  // Not a URL: treat as search query
  const engine = SEARCH_ENGINES[engineId] || SEARCH_ENGINES['duckduckgo'];
  return `${engine.queryUrl}${encodeURIComponent(trimmed)}`;
}

/**
 * Get favicon URL using Google's favicon service or default
 */
export function getFaviconUrl(url: string): string {
  if (!url || url.startsWith('vortex://')) {
    return '';
  }
  try {
    const parsed = new URL(url.startsWith('http') ? url : `https://${url}`);
    return `https://www.google.com/s2/favicons?domain=${parsed.hostname}&sz=64`;
  } catch {
    return '';
  }
}

/**
 * Clean URL for display in address bar
 */
export function formatDisplayUrl(url: string): string {
  if (url === 'vortex://home' || url === 'vortex://newtab') {
    return '';
  }
  return url;
}
