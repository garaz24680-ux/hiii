import { Bookmark, HistoryEntry, QuickLink, SearchEngineId, SecurityShieldConfig, UserProfile } from '../types/browser';
import { DEFAULT_QUICK_LINKS } from '../constants/defaultQuickLinks';
import { DEFAULT_SEARCH_ENGINE } from '../constants/searchEngines';

const STORAGE_KEYS = {
  USER_PROFILE: 'vortex_user_profile',
  SEARCH_ENGINE: 'vortex_search_engine',
  QUICK_LINKS: 'vortex_quick_links',
  BOOKMARKS: 'vortex_bookmarks',
  HISTORY: 'vortex_history',
  SECURITY_SHIELD: 'vortex_security_shield',
};

// User Profile
export function getStoredUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed reading user profile from localStorage', e);
  }
  return {
    username: '',
    hasCompletedOnboarding: false,
    selectedSearchEngine: DEFAULT_SEARCH_ENGINE as SearchEngineId,
    showBookmarkBar: true,
    themeAccent: 'purple',
  };
}

export function saveUserProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed saving user profile', e);
  }
}

// Search Engine
export function getStoredSearchEngine(): SearchEngineId {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.SEARCH_ENGINE);
    if (stored && ['google', 'bing', 'duckduckgo', 'brave'].includes(stored)) {
      return stored as SearchEngineId;
    }
  } catch (e) {
    console.error('Failed reading search engine', e);
  }
  return DEFAULT_SEARCH_ENGINE as SearchEngineId;
}

export function saveSearchEngine(engineId: SearchEngineId): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SEARCH_ENGINE, engineId);
  } catch (e) {
    console.error('Failed saving search engine', e);
  }
}

// Quick Links
export function getStoredQuickLinks(): QuickLink[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUICK_LINKS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading quick links', e);
  }
  return DEFAULT_QUICK_LINKS;
}

export function saveQuickLinks(links: QuickLink[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.QUICK_LINKS, JSON.stringify(links));
  } catch (e) {
    console.error('Failed saving quick links', e);
  }
}

// Bookmarks
export function getStoredBookmarks(): Bookmark[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading bookmarks', e);
  }
  return [];
}

export function saveBookmarks(bookmarks: Bookmark[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
  } catch (e) {
    console.error('Failed saving bookmarks', e);
  }
}

// History
export function getStoredHistory(): HistoryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading history', e);
  }
  return [];
}

export function saveHistory(history: HistoryEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  } catch (e) {
    console.error('Failed saving history', e);
  }
}

export function clearStoredHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.HISTORY);
  } catch (e) {
    console.error('Failed clearing history', e);
  }
}

// Security Shield
export function getStoredSecurityShield(): SecurityShieldConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SECURITY_SHIELD);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed reading security shield settings', e);
  }
  // Default is OFF per specifications
  return {
    enabled: false,
    blockAds: true,
    blockTrackers: true,
    blockPopups: true,
    preventFingerprinting: true,
    totalBlockedCount: 0,
  };
}

export function saveSecurityShield(config: SecurityShieldConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SECURITY_SHIELD, JSON.stringify(config));
  } catch (e) {
    console.error('Failed saving security shield settings', e);
  }
}
