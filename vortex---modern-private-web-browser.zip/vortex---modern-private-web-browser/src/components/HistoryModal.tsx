import React, { useState } from 'react';
import {
  X,
  History as HistoryIcon,
  Trash2,
  Search,
  ExternalLink,
  Globe,
  AlertCircle,
  Calendar,
} from 'lucide-react';
import { HistoryEntry } from '../types/browser';

interface HistoryModalProps {
  isOpen: boolean;
  history: HistoryEntry[];
  onClose: () => void;
  onNavigate: (url: string) => void;
  onDeleteEntry: (id: string) => void;
  onClearAllHistory: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  history,
  onClose,
  onNavigate,
  onDeleteEntry,
  onClearAllHistory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  if (!isOpen) return null;

  const filteredHistory = history.filter((entry) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      entry.title.toLowerCase().includes(q) ||
      entry.url.toLowerCase().includes(q)
    );
  });

  const formatDate = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-xl max-h-[85vh] bg-[#110c28] border border-purple-500/30 rounded-2xl shadow-2xl shadow-purple-950/90 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-purple-900/30 flex items-center justify-between bg-[#150f32]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-900/50 border border-purple-700/40 flex items-center justify-center text-purple-300">
              <HistoryIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Browsing History</h2>
              <span className="text-[11px] text-slate-400">
                {history.length} {history.length === 1 ? 'visit' : 'visits'} recorded
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* "Delete browsing history" button at the top per prompt */}
            {history.length > 0 && (
              <button
                type="button"
                onClick={() => setShowConfirmDelete(true)}
                className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/40 text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete browsing history</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-purple-900/40 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search bar inside history */}
        <div className="p-3 border-b border-purple-900/20 bg-[#0d0920]">
          <div className="flex items-center px-3 h-9 rounded-xl bg-[#171134] border border-purple-800/40 focus-within:border-purple-400 transition-colors">
            <Search className="w-3.5 h-3.5 text-purple-400 mr-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search history..."
              className="flex-1 bg-transparent border-none outline-none text-xs text-slate-100 placeholder-slate-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Entries List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5 min-h-[240px]">
          {filteredHistory.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <HistoryIcon className="w-8 h-8 text-purple-900/80 mb-2 stroke-1" />
              <p className="text-xs text-slate-400 font-medium">No history entries found</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {searchQuery ? 'Try matching a different keyword' : 'Pages you visit in Vortex will appear here'}
              </p>
            </div>
          ) : (
            filteredHistory.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onNavigate(item.url);
                  onClose();
                }}
                className="group flex items-center justify-between p-2.5 rounded-xl bg-[#161033]/60 hover:bg-[#1f1646] border border-purple-900/30 hover:border-purple-700/50 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Favicon */}
                  <div className="w-7 h-7 rounded-lg bg-purple-950/60 border border-purple-800/30 flex items-center justify-center shrink-0">
                    {item.favicon ? (
                      <img
                        src={item.favicon}
                        alt=""
                        className="w-4 h-4 object-contain"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <Globe className="w-3.5 h-3.5 text-purple-400" />
                    )}
                  </div>

                  {/* Title & URL */}
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold text-slate-200 group-hover:text-purple-200 truncate">
                      {item.title || item.url}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 truncate">
                      {item.url}
                    </div>
                  </div>
                </div>

                {/* Timestamp & Actions */}
                <div className="flex items-center gap-3 shrink-0 ml-3">
                  <span className="text-[10px] text-slate-500 whitespace-nowrap">
                    {formatDate(item.visitedAt)}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteEntry(item.id);
                    }}
                    className="p-1 rounded-md text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Remove from history"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Delete Confirmation Sub-Dialog */}
        {showConfirmDelete && (
          <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="w-full max-w-sm bg-[#181136] border border-rose-500/40 rounded-2xl p-6 shadow-2xl text-center">
              <div className="w-12 h-12 rounded-2xl bg-rose-950/70 border border-rose-700/50 flex items-center justify-center text-rose-400 mx-auto mb-3">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1.5">
                Clear all browsing history?
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-5">
                This will permanently delete all records of visited pages from Vortex. This action cannot be undone.
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowConfirmDelete(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-purple-950/60"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClearAllHistory();
                    setShowConfirmDelete(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-950/60"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
