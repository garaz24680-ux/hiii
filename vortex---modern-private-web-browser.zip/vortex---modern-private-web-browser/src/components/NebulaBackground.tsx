import React, { useEffect, useRef } from 'react';

interface NebulaBackgroundProps {
  intensity?: 'subtle' | 'normal' | 'vibrant';
}

export const NebulaBackground: React.FC<NebulaBackgroundProps> = ({ intensity = 'normal' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Stardust particles
    const particleCount = intensity === 'subtle' ? 45 : intensity === 'vibrant' ? 90 : 65;
    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.8 + 0.6,
      vx: (Math.random() - 0.5) * 0.25,
      vy: (Math.random() - 0.5) * 0.25,
      alpha: Math.random() * 0.7 + 0.2,
      pulseSpeed: Math.random() * 0.02 + 0.005,
      color: Math.random() > 0.4 ? 'rgba(168, 85, 247, ' : 'rgba(192, 132, 252, ',
    }));

    // Nebula cloud anchors with smooth floating trajectories
    const clouds = [
      { x: width * 0.35, y: height * 0.45, r: Math.min(width, height) * 0.55, color: [88, 28, 135], speed: 0.0006, offset: 0 },
      { x: width * 0.65, y: height * 0.4, r: Math.min(width, height) * 0.5, color: [109, 40, 217], speed: 0.0005, offset: 2.1 },
      { x: width * 0.5, y: height * 0.6, r: Math.min(width, height) * 0.45, color: [67, 24, 148], speed: 0.0008, offset: 4.2 },
      { x: width * 0.2, y: height * 0.3, r: Math.min(width, height) * 0.38, color: [124, 58, 237], speed: 0.0004, offset: 1.2 },
    ];

    let t = 0;

    const render = () => {
      t += 1;
      ctx.clearRect(0, 0, width, height);

      // Deep base void
      const baseGradient = ctx.createRadialGradient(
        width * 0.5,
        height * 0.4,
        100,
        width * 0.5,
        height * 0.5,
        Math.max(width, height)
      );
      baseGradient.addColorStop(0, '#0f0a28');
      baseGradient.addColorStop(0.5, '#090619');
      baseGradient.addColorStop(1, '#05030e');
      ctx.fillStyle = baseGradient;
      ctx.fillRect(0, 0, width, height);

      // Render cosmic nebula clouds with smooth organic motion
      ctx.globalCompositeOperation = 'screen';
      clouds.forEach((cloud) => {
        const cx = cloud.x + Math.sin(t * cloud.speed + cloud.offset) * 60;
        const cy = cloud.y + Math.cos(t * cloud.speed + cloud.offset) * 45;
        const currentR = cloud.r * (1 + Math.sin(t * 0.001 + cloud.offset) * 0.08);

        const radGrad = ctx.createRadialGradient(cx, cy, 10, cx, cy, currentR);
        const [r, g, b] = cloud.color;
        const opacityMultiplier = intensity === 'subtle' ? 0.18 : intensity === 'vibrant' ? 0.35 : 0.26;

        radGrad.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${opacityMultiplier})`);
        radGrad.addColorStop(0.5, `rgba(${r}, ${g}, ${b}, ${opacityMultiplier * 0.45})`);
        radGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = radGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, currentR, 0, Math.PI * 2);
        ctx.fill();
      });

      // Subtle vortex swirl center glow
      const swirlGrad = ctx.createRadialGradient(
        width * 0.5,
        height * 0.38,
        0,
        width * 0.5,
        height * 0.38,
        Math.min(width, height) * 0.35
      );
      swirlGrad.addColorStop(0, 'rgba(192, 132, 252, 0.18)');
      swirlGrad.addColorStop(0.4, 'rgba(147, 51, 234, 0.09)');
      swirlGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = swirlGrad;
      ctx.beginPath();
      ctx.arc(width * 0.5, height * 0.38, Math.min(width, height) * 0.35, 0, Math.PI * 2);
      ctx.fill();

      // Render stardust particles
      ctx.globalCompositeOperation = 'lighter';
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha += Math.sin(t * p.pulseSpeed) * 0.01;
        const alpha = Math.max(0.1, Math.min(0.85, p.alpha));

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.fillStyle = `${p.color}${alpha})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.globalCompositeOperation = 'source-over';
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none z-0"
      style={{ display: 'block', width: '100%', height: '100%' }}
    />
  );
};
