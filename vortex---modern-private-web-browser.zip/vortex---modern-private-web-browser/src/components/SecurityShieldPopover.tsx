import React from 'react';
import {
  Shield,
  ShieldOff,
  Info,
  ShieldAlert,
  Zap,
  EyeOff,
} from 'lucide-react';
import { SecurityShieldConfig } from '../types/browser';

interface SecurityShieldPopoverProps {
  isOpen: boolean;
  config: SecurityShieldConfig;
  currentHost?: string;
  onClose: () => void;
  onToggleShield: () => void;
  onUpdateConfig: (newConfig: Partial<SecurityShieldConfig>) => void;
}

export const SecurityShieldPopover: React.FC<SecurityShieldPopoverProps> = ({
  isOpen,
  config,
  onClose,
  onToggleShield,
  onUpdateConfig,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-end p-4 pt-16 pr-8 bg-black/40 backdrop-blur-[2px] select-none"
      onClick={onClose}
    >
      <div
        className="w-80 bg-[#130d2d] border border-purple-500/30 rounded-2xl p-5 shadow-2xl shadow-purple-950/90 text-left animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header / Big Toggle */}
        <div className="flex items-center justify-between pb-4 border-b border-purple-900/30">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                config.enabled
                  ? 'bg-purple-900/60 border border-purple-500/50 text-purple-300 shadow-sm shadow-purple-900/50'
                  : 'bg-slate-800/60 border border-slate-700/50 text-slate-500'
              }`}
            >
              {config.enabled ? (
                <Shield className="w-5 h-5 fill-purple-400/20 text-purple-300" />
              ) : (
                <ShieldOff className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="text-xs font-bold text-white tracking-normal">
                Vortex Privacy Shield
              </h3>
              <p className="text-[11px] text-slate-400">
                {config.enabled ? 'Protection active' : 'Protection disabled'}
              </p>
            </div>
          </div>

          {/* Master Switch Button */}
          <button
            type="button"
            onClick={onToggleShield}
            className={`relative w-12 h-6 rounded-full transition-colors duration-200 focus:outline-none ${
              config.enabled ? 'bg-purple-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-200 shadow-md ${
                config.enabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Protection Items */}
        <div className="py-3 space-y-2 border-b border-purple-900/30 text-xs">
          <div className="flex items-center justify-between py-1">
            <span className="text-slate-300 flex items-center gap-1.5">
              <EyeOff className="w-3.5 h-3.5 text-purple-400" />
              <span>Block web trackers & pixels</span>
            </span>
            <input
              type="checkbox"
              disabled={!config.enabled}
              checked={config.blockTrackers}
              onChange={(e) => onUpdateConfig({ blockTrackers: e.target.checked })}
              className="accent-purple-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>Block embedded ad scripts</span>
            </span>
            <input
              type="checkbox"
              disabled={!config.enabled}
              checked={config.blockAds}
              onChange={(e) => onUpdateConfig({ blockAds: e.target.checked })}
              className="accent-purple-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <span className="text-slate-300 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
              <span>Block popups & intrusive tabs</span>
            </span>
            <input
              type="checkbox"
              disabled={!config.enabled}
              checked={config.blockPopups}
              onChange={(e) => onUpdateConfig({ blockPopups: e.target.checked })}
              className="accent-purple-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Honest Disclosure Statement (Required by prompt) */}
        <div className="mt-3 p-2.5 rounded-xl bg-purple-950/30 border border-purple-900/30 text-[11px] text-slate-400 leading-normal">
          <div className="flex items-start gap-1.5">
            <Info className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
            <span>
              <strong>Sandbox Protections:</strong> Filters known tracking scripts, ad pixels, and unauthorized window popups inside the browser frame.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
