import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Star,
  Shield,
  ShieldOff,
  History as HistoryIcon,
  Bookmark as BookmarkIcon,
  User,
  X,
  Globe,
  SlidersHorizontal,
} from 'lucide-react';
import { Tab, SecurityShieldConfig, SearchEngineId, Bookmark } from '../types/browser';
import { resolveNavigationUrl, formatDisplayUrl } from '../utils/urlHelper';

interface ToolbarProps {
  activeTab: Tab;
  canGoBack: boolean;
  canGoForward: boolean;
  isBookmarked: boolean;
  shieldConfig: SecurityShieldConfig;
  selectedSearchEngine: SearchEngineId;
  username: string;
  bookmarks: Bookmark[];
  onNavigate: (url: string) => void;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: () => void;
  onGoHome: () => void;
  onToggleBookmark: () => void;
  onRemoveBookmark: (id: string) => void;
  onToggleShield: () => void;
  onOpenShieldPopup: () => void;
  onOpenHistory: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTab,
  canGoBack,
  canGoForward,
  isBookmarked,
  shieldConfig,
  selectedSearchEngine,
  username,
  bookmarks,
  onNavigate,
  onGoBack,
  onGoForward,
  onReload,
  onGoHome,
  onToggleBookmark,
  onRemoveBookmark,
  onToggleShield,
  onOpenShieldPopup,
  onOpenHistory,
}) => {
  const [inputUrl, setInputUrl] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const bookmarksRef = useRef<HTMLDivElement | null>(null);

  // Close bookmarks dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (bookmarksRef.current && !bookmarksRef.current.contains(e.target as Node)) {
        setIsBookmarksOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Sync address bar input with active tab URL
  useEffect(() => {
    if (!isFocused) {
      setInputUrl(formatDisplayUrl(activeTab.url));
    }
  }, [activeTab.url, isFocused]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;
    const resolved = resolveNavigationUrl(inputUrl, selectedSearchEngine);
    onNavigate(resolved);
    inputRef.current?.blur();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Escape') {
      setInputUrl(formatDisplayUrl(activeTab.url));
      inputRef.current?.blur();
    }
  };

  const isHome = activeTab.url === 'vortex://home' || activeTab.url === 'vortex://newtab';

  return (
    <div className="h-12 bg-[#0c0822] border-b-2 border-purple-800/50 flex items-center px-2 gap-2 select-none relative z-30 shadow-md">
      {/* Navigation Controls (Left) */}
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          onClick={onGoBack}
          disabled={!canGoBack}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors border ${
            canGoBack
              ? 'bg-[#1a1038] border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white'
              : 'bg-[#120a28] border-transparent text-slate-600 cursor-not-allowed opacity-40'
          }`}
          title="Back"
          aria-label="Back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onGoForward}
          disabled={!canGoForward}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors border ${
            canGoForward
              ? 'bg-[#1a1038] border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white'
              : 'bg-[#120a28] border-transparent text-slate-600 cursor-not-allowed opacity-40'
          }`}
          title="Forward"
          aria-label="Forward"
        >
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onReload}
          className={`w-8 h-8 rounded-lg flex items-center justify-center bg-[#1a1038] border border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white transition-all ${
            activeTab.isLoading ? 'animate-spin text-purple-400' : ''
          }`}
          title="Reload"
          aria-label="Reload"
        >
          <RotateCw className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onGoHome}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors border ${
            isHome
              ? 'bg-purple-700 border-purple-500 text-white'
              : 'bg-[#1a1038] border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white'
          }`}
          title="Home Page"
          aria-label="Home"
        >
          <Home className="w-4 h-4" />
        </button>
      </div>

      {/* Main Search Bar (Takes up the whole remaining space across the top!) */}
      <form onSubmit={handleSubmit} className="flex-1 w-full mx-1 flex items-center">
        <div
          className={`w-full h-9 rounded-full flex items-center px-4 gap-2 transition-all border-2 ${
            isFocused
              ? 'bg-[#170e3a] border-purple-400 shadow-lg shadow-purple-900/50'
              : 'bg-[#150d33] border-purple-800/70 hover:border-purple-600'
          }`}
        >
          <input
            ref={inputRef}
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            onFocus={() => {
              setIsFocused(true);
              inputRef.current?.select();
            }}
            onBlur={() => setIsFocused(false)}
            onKeyDown={handleKeyDown}
            placeholder="Search here or type a URL..."
            className="flex-1 bg-transparent border-none outline-none text-xs md:text-sm text-purple-100 placeholder-purple-400/50 font-medium selection:bg-purple-600 selection:text-white"
          />

          {/* Clear input button when typing */}
          {isFocused && inputUrl && (
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                setInputUrl('');
              }}
              className="text-purple-400 hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Star / Bookmark Button on right side of address bar */}
          <button
            type="button"
            onClick={onToggleBookmark}
            disabled={isHome}
            className={`w-7 h-7 rounded flex items-center justify-center transition-transform active:scale-90 ${
              isHome
                ? 'opacity-20 cursor-not-allowed text-slate-500'
                : isBookmarked
                ? 'text-amber-400 hover:text-amber-300'
                : 'text-purple-300 hover:text-white'
            }`}
            title={
              isHome
                ? 'Cannot bookmark home page'
                : isBookmarked
                ? 'Remove bookmark'
                : 'Bookmark this page'
            }
            aria-label="Bookmark"
          >
            <Star
              className={`w-4 h-4 ${
                isBookmarked ? 'fill-amber-400 text-amber-400' : ''
              }`}
            />
          </button>
        </div>
      </form>

      {/* Toolbar Right Controls (Security Shield, Bookmarks Tiny List, History, Static Avatar) */}
      <div className="flex items-center gap-1.5 shrink-0">
        {/* Security Shield Group (Toggle directly & settings popover) */}
        <div className="flex items-center rounded-lg bg-[#181035] border border-purple-800/60 overflow-hidden">
          <button
            type="button"
            onClick={onToggleShield}
            className={`h-8 px-2.5 flex items-center gap-1.5 transition-all text-xs font-bold ${
              shieldConfig.enabled
                ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-sm'
                : 'text-rose-400 hover:bg-rose-950/40'
            }`}
            title={`Privacy Shield: ${shieldConfig.enabled ? 'Active (Click to disable)' : 'Off (Click to enable)'}`}
            aria-label="Privacy Shield"
          >
            {shieldConfig.enabled ? (
              <>
                <Shield className="w-4 h-4 fill-white/25 text-white" />
                <span className="text-[11px] font-semibold hidden md:inline">Shield</span>
              </>
            ) : (
              <>
                <ShieldOff className="w-4 h-4 text-rose-400" />
                <span className="text-[11px] font-semibold hidden md:inline text-rose-300">Off</span>
              </>
            )}
          </button>

          {/* Quick settings trigger */}
          <button
            type="button"
            onClick={onOpenShieldPopup}
            className="h-8 px-1.5 hover:bg-purple-800/40 text-purple-300 hover:text-white border-l border-purple-800/40 transition-colors"
            title="Privacy Shield Settings"
            aria-label="Privacy Shield Settings"
          >
            <SlidersHorizontal className="w-3 h-3" />
          </button>
        </div>

        {/* Bookmarks Button with Tiny Dropdown List directly underneath */}
        <div className="relative" ref={bookmarksRef}>
          <button
            type="button"
            onClick={() => setIsBookmarksOpen(!isBookmarksOpen)}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors border ${
              isBookmarksOpen
                ? 'bg-purple-700 border-purple-500 text-white'
                : 'bg-[#1a1038] border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white'
            }`}
            title="Bookmarks list"
            aria-label="Bookmarks"
          >
            <BookmarkIcon className="w-4 h-4" />
          </button>

          {/* Tiny Dropdown List under the bookmarks button (No all-caps) */}
          {isBookmarksOpen && (
            <div className="absolute top-full right-0 mt-2 w-64 bg-[#140e32] border-2 border-purple-600 rounded-xl shadow-2xl p-2 z-50 text-left">
              <div className="px-2 py-1 text-xs font-bold text-purple-300 border-b border-purple-800/50 flex justify-between items-center mb-1">
                <span>Bookmarks</span>
                <span className="text-[10px] text-purple-400">{bookmarks.length}</span>
              </div>

              {bookmarks.length === 0 ? (
                <div className="p-3 text-center text-xs text-purple-300/60">
                  No bookmarks yet.<br />Click the ★ star to bookmark!
                </div>
              ) : (
                <div className="max-h-60 overflow-y-auto space-y-1 no-scrollbar">
                  {bookmarks.map((bm) => (
                    <div
                      key={bm.id}
                      onClick={() => {
                        onNavigate(bm.url);
                        setIsBookmarksOpen(false);
                      }}
                      className="group flex items-center justify-between p-1.5 rounded-lg hover:bg-purple-900/60 cursor-pointer text-xs transition-colors"
                      title={bm.url}
                    >
                      <div className="flex items-center gap-2 truncate flex-1 min-w-0">
                        {bm.favicon ? (
                          <img
                            src={bm.favicon}
                            alt=""
                            className="w-3.5 h-3.5 object-contain rounded shrink-0"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.currentTarget as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          <Globe className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                        )}
                        <span className="truncate text-slate-200 group-hover:text-white font-medium">
                          {bm.title || bm.url}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveBookmark(bm.id);
                        }}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-950/40"
                        title="Delete bookmark"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* History button */}
        <button
          type="button"
          onClick={onOpenHistory}
          className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#1a1038] border border-purple-700/60 text-purple-200 hover:bg-purple-800/50 hover:text-white transition-colors"
          title="History"
          aria-label="History"
        >
          <HistoryIcon className="w-4 h-4" />
        </button>

        {/* User Avatar - Non-clickable per prompt */}
        <div
          className="h-8 pl-1.5 pr-2.5 rounded-full flex items-center gap-1.5 bg-[#170e38] border border-purple-700/50 text-purple-200 select-none cursor-default"
          title={`User: ${username || 'User'}`}
        >
          <div className="w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center text-[10px] font-bold text-white shadow-sm">
            {username ? username.charAt(0).toUpperCase() : <User className="w-3 h-3" />}
          </div>
          <span className="text-xs font-semibold max-w-[70px] truncate hidden sm:inline text-purple-200">
            {username || 'User'}
          </span>
        </div>
      </div>
    </div>
  );
};
