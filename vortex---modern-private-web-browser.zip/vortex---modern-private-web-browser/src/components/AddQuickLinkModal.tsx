import React, { useState, useEffect } from 'react';
import { X, Globe, Sparkles, Check } from 'lucide-react';
import { QuickLink } from '../types/browser';
import { getFaviconUrl } from '../utils/urlHelper';

interface AddQuickLinkModalProps {
  isOpen: boolean;
  initialLink?: QuickLink | null;
  onClose: () => void;
  onSave: (linkData: { id?: string; title: string; url: string; favicon: string }) => void;
}

export const AddQuickLinkModal: React.FC<AddQuickLinkModalProps> = ({
  isOpen,
  initialLink,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [favicon, setFavicon] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialLink) {
      setTitle(initialLink.title);
      setUrl(initialLink.url);
      setFavicon(initialLink.favicon);
    } else {
      setTitle('');
      setUrl('');
      setFavicon('');
    }
    setError('');
  }, [initialLink, isOpen]);

  if (!isOpen) return null;

  // Auto-fetch favicon preview when URL is entered
  const handleUrlChange = (value: string) => {
    setUrl(value);
    if (error) setError('');
    if (value.trim()) {
      const icon = getFaviconUrl(value);
      setFavicon(icon);
    } else {
      setFavicon('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTitle = title.trim();
    let cleanUrl = url.trim();

    if (!cleanTitle) {
      setError('Please enter a website name.');
      return;
    }
    if (!cleanUrl) {
      setError('Please enter a website URL.');
      return;
    }

    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = `https://${cleanUrl}`;
    }

    try {
      new URL(cleanUrl);
    } catch {
      setError('Please enter a valid website URL.');
      return;
    }

    const resolvedFavicon = favicon || getFaviconUrl(cleanUrl);

    onSave({
      id: initialLink ? initialLink.id : undefined,
      title: cleanTitle,
      url: cleanUrl,
      favicon: resolvedFavicon,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-sm bg-[#130e2c] border border-purple-500/30 rounded-2xl p-6 shadow-2xl shadow-purple-950/80">
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-900/50 border border-purple-700/40 flex items-center justify-center text-purple-300">
              <Globe className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {initialLink ? 'Edit Quick Link' : 'Add New Quick Link'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-purple-950/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-xs font-semibold text-purple-300 mb-1">
              Website Name
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Reddit, Wikipedia"
              autoFocus
              className="w-full h-10 px-3.5 rounded-xl bg-[#191238] border border-purple-700/40 focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-white text-xs outline-none transition-all placeholder-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-purple-300 mb-1">
              Website URL
            </label>
            <input
              type="text"
              value={url}
              onChange={(e) => handleUrlChange(e.target.value)}
              placeholder="e.g. https://reddit.com"
              className="w-full h-10 px-3.5 rounded-xl bg-[#191238] border border-purple-700/40 focus:border-purple-400 focus:ring-1 focus:ring-purple-400 text-white text-xs outline-none transition-all placeholder-slate-500 font-mono"
            />
          </div>

          {/* Favicon Preview */}
          {favicon && (
            <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-950/40 border border-purple-900/40 text-xs text-purple-200">
              <img
                src={favicon}
                alt=""
                className="w-5 h-5 rounded object-contain bg-white/10 p-0.5"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
              <span className="text-[11px] text-slate-300">Favicon automatically resolved</span>
            </div>
          )}

          {error && <p className="text-[11px] text-rose-400 font-medium">{error}</p>}

          <div className="flex items-center justify-end gap-2 mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-purple-950/40 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-all shadow-md shadow-purple-950/60 active:scale-95"
            >
              {initialLink ? 'Save Changes' : 'Add Quick Link'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
