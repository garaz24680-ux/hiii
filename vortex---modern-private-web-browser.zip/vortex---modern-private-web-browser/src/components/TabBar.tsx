import React from 'react';
import { Plus, X, Globe, Compass, Minus, Square } from 'lucide-react';
import { Tab } from '../types/browser';

interface TabBarProps {
  tabs: Tab[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onNewTab: () => void;
}

export const TabBar: React.FC<TabBarProps> = ({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
}) => {
  return (
    <div className="h-10 bg-[#08041a] border-b-2 border-purple-800/60 flex items-center px-2 select-none justify-between gap-2 overflow-hidden">
      {/* Tab list */}
      <div className="flex items-center gap-1.5 flex-1 min-w-0 overflow-x-auto no-scrollbar py-1">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          const isHome = tab.url === 'vortex://home' || tab.url === 'vortex://newtab';

          return (
            <div
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`group relative flex items-center gap-2 h-8 px-2.5 rounded-t-xl cursor-pointer transition-all duration-150 max-w-[220px] min-w-[120px] shrink-0 border-t-2 border-x-2 ${
                isActive
                  ? 'bg-[#c7d2fe] text-slate-950 border-purple-400 font-bold shadow-md'
                  : 'bg-[#181138] text-purple-300 border-purple-900/60 hover:bg-[#22174d] hover:text-white font-medium'
              }`}
              title={tab.title || (isHome ? 'New Tab' : tab.url)}
            >
              {/* Favicon or icon on Left */}
              <div className="w-3.5 h-3.5 shrink-0 flex items-center justify-center">
                {tab.isLoading ? (
                  <div className="w-3 h-3 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                ) : isHome ? (
                  <Compass className="w-3.5 h-3.5 text-purple-700" />
                ) : tab.favicon ? (
                  <img
                    src={tab.favicon}
                    alt=""
                    className="w-3.5 h-3.5 object-contain rounded-sm"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <Globe className="w-3.5 h-3.5 text-slate-600" />
                )}
              </div>

              {/* Tab Title in Middle */}
              <span className="text-xs truncate flex-1 tracking-tight">
                {tab.title || (isHome ? 'New Tab' : tab.url)}
              </span>

              {/* Improved Tab Close 'X' Button on the RIGHT */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab(tab.id);
                }}
                className={`w-5 h-5 rounded-md flex items-center justify-center transition-all duration-150 shrink-0 ${
                  isActive
                    ? 'text-slate-700 hover:text-white hover:bg-rose-500/90 active:bg-rose-600'
                    : 'text-purple-400/80 hover:text-white hover:bg-rose-500/90 active:bg-rose-600'
                }`}
                title="Close Tab"
                aria-label="Close tab"
              >
                <X className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>
          );
        })}

        {/* Plus / New Tab Button */}
        <button
          type="button"
          onClick={onNewTab}
          className="w-7 h-7 rounded-full bg-[#181138] hover:bg-purple-600 border-2 border-purple-500/80 hover:border-purple-300 flex items-center justify-center text-purple-200 hover:text-white transition-all ml-1 shrink-0 shadow-sm"
          title="New Tab (Ctrl+T)"
          aria-label="New tab"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
        </button>
      </div>

      {/* Modern Desktop Window Controls on Far Right */}
      <div className="flex items-center gap-1 pl-2 pr-1 shrink-0">
        <button
          type="button"
          className="w-6 h-6 rounded flex items-center justify-center text-purple-400 hover:text-white hover:bg-purple-900/50 transition-colors"
          title="Minimize"
          aria-label="Minimize"
        >
          <Minus className="w-3 h-3 stroke-[2.5]" />
        </button>
        <button
          type="button"
          className="w-6 h-6 rounded flex items-center justify-center text-purple-400 hover:text-white hover:bg-purple-900/50 transition-colors"
          title="Maximize"
          aria-label="Maximize"
        >
          <Square className="w-2.5 h-2.5 stroke-[2]" />
        </button>
        <button
          type="button"
          className="w-6 h-6 rounded flex items-center justify-center text-purple-400 hover:text-white hover:bg-rose-600 transition-colors"
          title="Close Window"
          aria-label="Close window"
        >
          <X className="w-3.5 h-3.5 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
