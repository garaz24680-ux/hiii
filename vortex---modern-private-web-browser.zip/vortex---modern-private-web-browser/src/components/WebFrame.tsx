import React, { useState, useEffect, useRef } from 'react';
import {
  AlertTriangle,
  RotateCw,
  ExternalLink,
  Shield,
  ShieldOff,
  Home,
  Lock,
} from 'lucide-react';
import { Tab, SecurityShieldConfig, SearchEngineId } from '../types/browser';
import { xor } from '../uv/codecs';

interface WebFrameProps {
  tab: Tab;
  shieldConfig: SecurityShieldConfig;
  selectedSearchEngine: SearchEngineId;
  onUpdateMetadata: (tabId: string, metadata: { title?: string; favicon?: string; blockedCount?: number }) => void;
  onNavigate: (url: string) => void;
  onReload: () => void;
}

export const WebFrame: React.FC<WebFrameProps> = ({
  tab,
  shieldConfig,
  onUpdateMetadata,
  onNavigate,
  onReload,
}) => {
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadingProgress, setLoadingProgress] = useState(30);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  // Derive Ultraviolet proxy URL with current shield state
  const proxyUrl = `/service/${xor.encode(tab.url)}?shield=${shieldConfig.enabled}`;

  // Reset errors and animate progress when tab url changes
  useEffect(() => {
    setLoadError(null);
    setLoadingProgress(35);

    const progressTimer1 = setTimeout(() => setLoadingProgress(75), 300);
    const progressTimer2 = setTimeout(() => setLoadingProgress(90), 800);

    return () => {
      clearTimeout(progressTimer1);
      clearTimeout(progressTimer2);
    };
  }, [tab.url]);

  // Fetch page metadata via API if not yet set
  useEffect(() => {
    if (!tab.url.startsWith('http')) return;

    let isMounted = true;
    fetch(`/api/metadata?url=${encodeURIComponent(tab.url)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!isMounted) return;
        if (data.title || data.favicon) {
          onUpdateMetadata(tab.id, {
            title: data.title,
            favicon: data.favicon,
          });
        }
      })
      .catch(() => {
        try {
          const parsed = new URL(tab.url);
          onUpdateMetadata(tab.id, { title: parsed.hostname });
        } catch {}
      });

    return () => {
      isMounted = false;
    };
  }, [tab.url, tab.id, onUpdateMetadata]);

  // Listen to postMessage from the bridge script injected in the proxy
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (!e.data) return;

      // When bridge informs of loaded page
      if (e.data.type === 'VORTEX_FRAME_LOADED') {
        setLoadingProgress(100);
        onUpdateMetadata(tab.id, {
          title: e.data.title || undefined,
          blockedCount: typeof e.data.blockedCount === 'number' ? e.data.blockedCount : 0,
        });
      }

      // When user clicks a link or submits a search form inside the proxied page!
      if (e.data.type === 'VORTEX_NAVIGATE' && e.data.url) {
        if (typeof e.data.url === 'string' && e.data.url.trim()) {
          onNavigate(e.data.url.trim());
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [tab.id, onUpdateMetadata, onNavigate]);

  const handleIframeLoad = () => {
    setLoadingProgress(100);
  };

  const handleIframeError = () => {
    setLoadError('Failed to establish connection via Ultraviolet proxy engine.');
  };

  let hostname = '';
  try {
    hostname = new URL(tab.url).hostname;
  } catch {
    hostname = tab.url;
  }

  return (
    <div className="relative w-full h-full flex flex-col bg-[#070512] overflow-hidden">
      {/* Sleek top loading progress bar */}
      {tab.isLoading && (
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-purple-950 z-30 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-purple-400 via-fuchsia-400 to-indigo-400 transition-all duration-300 ease-out"
            style={{ width: `${loadingProgress}%` }}
          />
        </div>
      )}

      {/* Frame Header / UV Engine Banner */}
      <div className="h-7 bg-[#0f0a28] border-b border-purple-800/40 px-3 flex items-center justify-between text-[11px] text-purple-200 select-none shrink-0 z-20">
        <div className="flex items-center gap-2 truncate">
          <div className="flex items-center gap-1.5 text-purple-300 font-bold">
            <Lock className="w-3 h-3 text-emerald-400" />
            <span className="truncate">{hostname}</span>
          </div>
          <span className="text-purple-600">·</span>
          <span className="text-purple-400 text-[10px] hidden sm:inline font-mono">
            Ultraviolet Engine
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {shieldConfig.enabled ? (
            <div className="flex items-center gap-1.5 text-purple-200 bg-purple-900/60 px-2 py-0.5 rounded border border-purple-500/50 text-[10px] font-bold shadow-sm">
              <Shield className="w-2.5 h-2.5 text-purple-300 fill-purple-400/20" />
              <span>
                {tab.blockedTrackers > 0
                  ? `${tab.blockedTrackers} threats blocked`
                  : 'Shield active'}
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-1 text-slate-400 bg-slate-900/60 px-2 py-0.5 rounded border border-slate-700/50 text-[10px]">
              <ShieldOff className="w-2.5 h-2.5 text-rose-400" />
              <span>Shield off</span>
            </div>
          )}

          <a
            href={tab.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-purple-300 hover:text-white transition-colors text-[10px] font-semibold"
            title="Open website directly in external window"
          >
            <span>External</span>
            <ExternalLink className="w-2.5 h-2.5" />
          </a>
        </div>
      </div>

      {/* Error state if proxy failed */}
      {loadError ? (
        <div className="flex-1 flex items-center justify-center p-6 bg-[#080516]">
          <div className="max-w-md w-full bg-[#130d2e] border-2 border-purple-600 rounded-2xl p-6 shadow-2xl text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-950/60 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h2 className="text-base font-bold text-white mb-1">
              Unable to Load Webpage
            </h2>
            <div className="text-xs font-mono text-purple-300 bg-black/60 px-3 py-1.5 rounded-lg mb-3 break-all max-w-full">
              {tab.url}
            </div>

            <p className="text-xs text-purple-200/80 leading-relaxed mb-6">
              The Ultraviolet proxy engine could not establish a connection to this server.
            </p>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onReload}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('vortex://home')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Home Page</span>
              </button>

              <a
                href={tab.url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800 text-white border border-purple-500/40 text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open Direct</span>
              </a>
            </div>
          </div>
        </div>
      ) : (
        /* Actual Embedded Browser Frame running Ultraviolet proxy */
        <iframe
          key={`${tab.id}-${tab.url}-${shieldConfig.enabled}`}
          ref={iframeRef}
          src={proxyUrl}
          title={tab.title || 'Vortex Ultraviolet Frame'}
          onLoad={handleIframeLoad}
          onError={handleIframeError}
          className="flex-1 w-full h-full border-none bg-white"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
        />
      )}
    </div>
  );
};
