import React, { useState } from 'react';

interface WelcomeModalProps {
  isOpen: boolean;
  onComplete: (username: string) => void;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({ isOpen, onComplete }) => {
  const [usernameInput, setUsernameInput] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = usernameInput.trim();
    if (!trimmed) {
      setError('Please enter a username to personalize your browser.');
      return;
    }
    if (trimmed.length > 24) {
      setError('Username cannot exceed 24 characters.');
      return;
    }
    onComplete(trimmed);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-md bg-[#110c28] border border-purple-500/30 rounded-3xl p-8 shadow-2xl shadow-purple-950/80 overflow-hidden text-center">
        {/* Glow backdrop */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Vortex Logo Emblem */}
        <div className="relative mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-700 to-indigo-600 p-[1.5px] shadow-lg shadow-purple-900/50 flex items-center justify-center mb-6">
          <div className="w-full h-full bg-[#110c28] rounded-[14px] flex items-center justify-center">
            <svg className="w-8 h-8 text-purple-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" className="opacity-30 stroke-purple-400" />
              <path d="M12 2a10 10 0 0 1 10 10" className="stroke-purple-300" />
              <path d="M12 6a6 6 0 0 1 6 6" className="stroke-fuchsia-300" />
              <circle cx="12" cy="12" r="2" className="fill-purple-300" />
            </svg>
          </div>
        </div>

        {/* Modal Title */}
        <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-100 to-purple-300 mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          Welcome to Vortex
        </h2>
        <p className="text-xs text-slate-300/80 mb-6 leading-relaxed">
          Your private, futuristic gateway to the open web. Please choose a username to personalize your browser profile.
        </p>

        {/* Username Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-left">
          <div>
            <label htmlFor="vortex-username" className="block text-xs font-semibold text-purple-300 mb-1.5">
              Enter your username
            </label>
            <input
              id="vortex-username"
              type="text"
              value={usernameInput}
              onChange={(e) => {
                setUsernameInput(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Neo, Cypher, Traveler..."
              className="w-full h-11 px-4 rounded-xl bg-[#1c1440] border border-purple-500/50 text-white placeholder-purple-400/50 text-sm focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-600/30 transition-all font-medium"
              autoFocus
            />
            {error && (
              <p className="text-[11px] text-rose-400 mt-1.5 flex items-center gap-1 font-medium">
                {error}
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full h-11 mt-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-900/60 transition-all duration-150 active:scale-[0.98]"
          >
            <span>Get Started</span>
          </button>
        </form>
      </div>
    </div>
  );
};
