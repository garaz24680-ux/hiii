import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  ChevronDown,
  Plus,
  Trash2,
  Edit2,
  Globe,
} from 'lucide-react';
import { QuickLink, SearchEngineId } from '../types/browser';
import { SEARCH_ENGINES } from '../constants/searchEngines';
import { NebulaBackground } from './NebulaBackground';
import { resolveNavigationUrl } from '../utils/urlHelper';

interface HomePageProps {
  username: string;
  selectedSearchEngine: SearchEngineId;
  quickLinks: QuickLink[];
  shieldEnabled: boolean;
  onSelectSearchEngine: (engineId: SearchEngineId) => void;
  onNavigate: (url: string) => void;
  onOpenAddQuickLink: () => void;
  onEditQuickLink: (link: QuickLink) => void;
  onDeleteQuickLink: (id: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  username,
  selectedSearchEngine,
  quickLinks,
  onSelectSearchEngine,
  onNavigate,
  onOpenAddQuickLink,
  onEditQuickLink,
  onDeleteQuickLink,
}) => {
  const [query, setQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const currentEngine = SEARCH_ENGINES[selectedSearchEngine] || SEARCH_ENGINES.duckduckgo;

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) {
      onNavigate(currentEngine.homeUrl);
      return;
    }
    const resolvedUrl = resolveNavigationUrl(query, selectedSearchEngine);
    onNavigate(resolvedUrl);
  };

  return (
    <div
      className="relative w-full h-full flex flex-col items-center justify-center p-6 overflow-y-auto no-scrollbar select-none"
    >
      {/* Animated Purple Nebula Background */}
      <NebulaBackground intensity="vibrant" />

      {/* Content Container */}
      <div className="relative z-10 w-full max-w-2xl flex flex-col items-center text-center my-auto py-8">
        
        {/* Simple 3D Vortex Title */}
        <div className="mb-2 select-none">
          <h1
            className="text-6xl sm:text-7xl md:text-8xl font-black tracking-normal text-white select-none cursor-default"
            style={{
              textShadow: '0 2px 0 #a855f7, 0 4px 0 #7e22ce, 0 6px 0 #581c87, 0 8px 16px rgba(0, 0, 0, 0.6)',
            }}
          >
            Vortex
          </h1>
        </div>

        {/* Text under Vortex: Welcome (Username) - Normal casing */}
        <p className="text-base md:text-lg font-bold text-purple-200 tracking-normal mb-8 drop-shadow">
          Welcome {username || '(Username)'}
        </p>

        {/* Central Search Bar with Integrated Engine Selector - Normal Casing */}
        <div className="w-full mb-10">
          <form
            onSubmit={handleSearchSubmit}
            className="w-full flex items-center bg-[#150e33] border-2 border-purple-500 hover:border-purple-400 rounded-full p-1.5 transition-all shadow-xl shadow-purple-950/80"
          >
            {/* Search Engine Selector Dropdown Button */}
            <div className="relative shrink-0" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="h-10 px-4 rounded-full bg-[#241552] hover:bg-[#2d1b66] border border-purple-400 text-purple-100 text-xs font-semibold flex items-center gap-2 transition-colors active:scale-95 shadow-sm"
                title="Change Search Engine"
              >
                <img
                  src={currentEngine.icon}
                  alt=""
                  className="w-4 h-4 object-contain rounded"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <span className="hidden sm:inline font-semibold">{currentEngine.name}</span>
                <ChevronDown className={`w-3.5 h-3.5 text-purple-300 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Dropdown Menu */}
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-[#160f38] border-2 border-purple-500 rounded-2xl shadow-2xl py-1.5 z-50 text-left">
                  <div className="px-3 py-1 text-[11px] font-bold text-purple-300 border-b border-purple-800">
                    Search Engine
                  </div>
                  {Object.values(SEARCH_ENGINES).map((engine) => (
                    <button
                      key={engine.id}
                      type="button"
                      onClick={() => {
                        onSelectSearchEngine(engine.id);
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-2 flex items-center gap-2.5 text-xs text-left transition-colors ${
                        selectedSearchEngine === engine.id
                          ? 'bg-purple-700 text-white font-bold'
                          : 'text-purple-200 hover:bg-purple-900/60 hover:text-white'
                      }`}
                    >
                      <img
                        src={engine.icon}
                        alt=""
                        className="w-4 h-4 object-contain rounded"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = 'none';
                        }}
                      />
                      <span className="flex-1">{engine.name}</span>
                      {selectedSearchEngine === engine.id && (
                        <span className="w-2 h-2 rounded-full bg-white" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search Input - Not all caps */}
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search the web or type a URL..."
              className="flex-1 bg-transparent border-none outline-none px-4 text-sm md:text-base text-purple-100 placeholder-purple-400/50 font-medium selection:bg-purple-600 selection:text-white"
              autoFocus
            />

            {/* Search Submit Button */}
            <button
              type="submit"
              className="h-10 px-5 rounded-full bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:inline">Search</span>
            </button>
          </form>
        </div>

        {/* Quick Links Section (No heading text per request) */}
        <div className="w-full">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {quickLinks.map((link) => (
              <div
                key={link.id}
                onClick={() => onNavigate(link.url)}
                className="group relative flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#c7d2fe]/90 hover:bg-white text-slate-900 border-2 border-purple-500/70 hover:border-purple-300 transition-all duration-150 cursor-pointer shadow-lg shadow-purple-950/60 hover:-translate-y-1 active:translate-y-0"
                title={`${link.title}\n${link.url}`}
              >
                {link.isCustom && (
                  <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 z-20">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditQuickLink(link);
                      }}
                      className="p-1 rounded hover:bg-purple-200 text-slate-700"
                      title="Edit"
                    >
                      <Edit2 className="w-2.5 h-2.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteQuickLink(link.id);
                      }}
                      className="p-1 rounded hover:bg-rose-200 text-rose-700"
                      title="Delete"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                )}

                <div className="w-10 h-10 rounded-xl bg-white/80 border border-purple-300 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform overflow-hidden p-2 shadow-sm">
                  {link.favicon ? (
                    <img
                      src={link.favicon}
                      alt={link.title}
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                        const parent = (e.currentTarget as HTMLElement).parentElement;
                        if (parent) {
                          parent.innerHTML = '<span class="text-xs font-bold text-purple-900">' + (link.title.charAt(0) || 'W') + '</span>';
                        }
                      }}
                    />
                  ) : (
                    <Globe className="w-5 h-5 text-purple-700" />
                  )}
                </div>

                <span className="text-xs font-bold text-slate-900 group-hover:text-purple-950 truncate max-w-full">
                  {link.title}
                </span>
              </div>
            ))}

            {/* Plus / Add Quick Link Card - STRICTLY NO TEXT UNDER IT per user prompt */}
            <button
              type="button"
              onClick={onOpenAddQuickLink}
              className="flex items-center justify-center p-3.5 h-[98px] rounded-2xl bg-[#c7d2fe]/40 hover:bg-[#c7d2fe]/80 border-2 border-dashed border-purple-400 hover:border-purple-200 transition-all duration-150 cursor-pointer group shadow-sm hover:-translate-y-1 active:translate-y-0"
              title="Add Quick Link"
              aria-label="Add Quick Link"
            >
              <div className="w-12 h-12 rounded-xl bg-purple-900/40 border border-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform text-purple-200 group-hover:text-white">
                <Plus className="w-7 h-7 stroke-[3]" />
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
