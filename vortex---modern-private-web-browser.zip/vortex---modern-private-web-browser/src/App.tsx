/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Tab,
  QuickLink,
  Bookmark,
  HistoryEntry,
  SecurityShieldConfig,
  UserProfile,
  SearchEngineId,
} from './types/browser';
import {
  getStoredUserProfile,
  saveUserProfile,
  getStoredSearchEngine,
  saveSearchEngine,
  getStoredQuickLinks,
  saveQuickLinks,
  getStoredBookmarks,
  saveBookmarks,
  getStoredHistory,
  saveHistory,
  clearStoredHistory,
  getStoredSecurityShield,
  saveSecurityShield,
} from './utils/storage';
import { resolveNavigationUrl, getFaviconUrl } from './utils/urlHelper';
import { TabBar } from './components/TabBar';
import { Toolbar } from './components/Toolbar';
import { HomePage } from './components/HomePage';
import { WebFrame } from './components/WebFrame';
import { WelcomeModal } from './components/WelcomeModal';
import { AddQuickLinkModal } from './components/AddQuickLinkModal';
import { HistoryModal } from './components/HistoryModal';
import { SecurityShieldPopover } from './components/SecurityShieldPopover';

export default function App() {
  // Persistent state
  const [userProfile, setUserProfile] = useState<UserProfile>(getStoredUserProfile);
  const [selectedSearchEngine, setSelectedSearchEngine] = useState<SearchEngineId>(getStoredSearchEngine);
  const [quickLinks, setQuickLinks] = useState<QuickLink[]>(getStoredQuickLinks);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(getStoredBookmarks);
  const [history, setHistory] = useState<HistoryEntry[]>(getStoredHistory);
  const [shieldConfig, setShieldConfig] = useState<SecurityShieldConfig>(getStoredSecurityShield);

  // Modals & Panels
  const [isWelcomeModalOpen, setIsWelcomeModalOpen] = useState(false);
  const [isAddQuickLinkOpen, setIsAddQuickLinkOpen] = useState(false);
  const [editingQuickLink, setEditingQuickLink] = useState<QuickLink | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isShieldPopupOpen, setIsShieldPopupOpen] = useState(false);

  // Browser Tabs state
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: 'tab-1',
      title: 'New Tab',
      url: 'vortex://home',
      favicon: '',
      history: ['vortex://home'],
      historyIndex: 0,
      isLoading: false,
      error: null,
      blockedTrackers: 0,
    },
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('tab-1');

  // Active tab helper
  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  // First launch check
  useEffect(() => {
    if (!userProfile.hasCompletedOnboarding || !userProfile.username) {
      setIsWelcomeModalOpen(true);
    }
  }, [userProfile.hasCompletedOnboarding, userProfile.username]);

  // Handle first launch welcome completion
  const handleWelcomeComplete = (username: string) => {
    const updated: UserProfile = {
      ...userProfile,
      username,
      hasCompletedOnboarding: true,
    };
    setUserProfile(updated);
    saveUserProfile(updated);
    setIsWelcomeModalOpen(false);
  };

  // Switch search engine
  const handleSelectSearchEngine = (engineId: SearchEngineId) => {
    setSelectedSearchEngine(engineId);
    saveSearchEngine(engineId);
    const updated = { ...userProfile, selectedSearchEngine: engineId };
    setUserProfile(updated);
    saveUserProfile(updated);
  };

  // Add or update quick link
  const handleSaveQuickLink = (data: { id?: string; title: string; url: string; favicon: string }) => {
    let updated: QuickLink[];
    if (data.id) {
      updated = quickLinks.map((link) =>
        link.id === data.id
          ? { ...link, title: data.title, url: data.url, favicon: data.favicon, isCustom: true }
          : link
      );
    } else {
      const newLink: QuickLink = {
        id: `custom-${Date.now()}`,
        title: data.title,
        url: data.url,
        favicon: data.favicon,
        isCustom: true,
      };
      updated = [...quickLinks, newLink];
    }
    setQuickLinks(updated);
    saveQuickLinks(updated);
  };

  // Delete quick link
  const handleDeleteQuickLink = (id: string) => {
    const updated = quickLinks.filter((link) => link.id !== id);
    setQuickLinks(updated);
    saveQuickLinks(updated);
  };

  // Open Edit quick link modal
  const handleEditQuickLink = (link: QuickLink) => {
    setEditingQuickLink(link);
    setIsAddQuickLinkOpen(true);
  };

  // Record a visited URL to history
  const recordHistory = useCallback((url: string, title?: string, favicon?: string) => {
    if (url === 'vortex://home' || url === 'vortex://newtab' || url.startsWith('vortex://')) {
      return;
    }
    setHistory((prev) => {
      const filtered = prev.filter((item) => item.url !== url);
      const newEntry: HistoryEntry = {
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        title: title || url,
        url,
        favicon: favicon || getFaviconUrl(url),
        visitedAt: Date.now(),
      };
      const updated = [newEntry, ...filtered].slice(0, 500);
      saveHistory(updated);
      return updated;
    });
  }, []);

  // Clear history
  const handleClearHistory = () => {
    setHistory([]);
    clearStoredHistory();
  };

  const handleDeleteHistoryEntry = (id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      saveHistory(updated);
      return updated;
    });
  };

  // Bookmarks toggle
  const isCurrentBookmarked = bookmarks.some((b) => b.url === activeTab.url);

  const handleToggleBookmark = () => {
    if (activeTab.url === 'vortex://home' || activeTab.url === 'vortex://newtab') {
      return;
    }
    if (isCurrentBookmarked) {
      const updated = bookmarks.filter((b) => b.url !== activeTab.url);
      setBookmarks(updated);
      saveBookmarks(updated);
    } else {
      const newBookmark: Bookmark = {
        id: `bm-${Date.now()}`,
        title: activeTab.title || activeTab.url,
        url: activeTab.url,
        favicon: activeTab.favicon || getFaviconUrl(activeTab.url),
        createdAt: Date.now(),
      };
      const updated = [...bookmarks, newBookmark];
      setBookmarks(updated);
      saveBookmarks(updated);
    }
  };

  const handleRemoveBookmark = (id: string) => {
    const updated = bookmarks.filter((b) => b.id !== id);
    setBookmarks(updated);
    saveBookmarks(updated);
  };

  // Toggle Security Shield
  const handleToggleShield = () => {
    const updated: SecurityShieldConfig = {
      ...shieldConfig,
      enabled: !shieldConfig.enabled,
    };
    setShieldConfig(updated);
    saveSecurityShield(updated);
  };

  const handleUpdateShieldConfig = (partial: Partial<SecurityShieldConfig>) => {
    const updated: SecurityShieldConfig = {
      ...shieldConfig,
      ...partial,
    };
    setShieldConfig(updated);
    saveSecurityShield(updated);
  };

  // Navigation action for active tab
  const handleNavigate = useCallback(
    (targetUrl: string) => {
      const resolved = resolveNavigationUrl(targetUrl, selectedSearchEngine);

      setTabs((prevTabs) =>
        prevTabs.map((tab) => {
          if (tab.id !== activeTabId) return tab;

          const newHistory = [...tab.history.slice(0, tab.historyIndex + 1), resolved];
          const isHome = resolved === 'vortex://home' || resolved === 'vortex://newtab';

          return {
            ...tab,
            url: resolved,
            title: isHome ? 'New Tab' : resolved,
            favicon: isHome ? '' : getFaviconUrl(resolved),
            history: newHistory,
            historyIndex: newHistory.length - 1,
            isLoading: !isHome,
            error: null,
            blockedTrackers: 0,
          };
        })
      );

      if (!resolved.startsWith('vortex://')) {
        recordHistory(resolved);
      }
    },
    [activeTabId, selectedSearchEngine, recordHistory]
  );

  // Tab Navigation: Back
  const handleGoBack = () => {
    setTabs((prevTabs) =>
      prevTabs.map((tab) => {
        if (tab.id !== activeTabId || tab.historyIndex <= 0) return tab;
        const newIndex = tab.historyIndex - 1;
        const targetUrl = tab.history[newIndex];
        const isHome = targetUrl === 'vortex://home' || targetUrl === 'vortex://newtab';

        return {
          ...tab,
          url: targetUrl,
          title: isHome ? 'New Tab' : targetUrl,
          favicon: isHome ? '' : getFaviconUrl(targetUrl),
          historyIndex: newIndex,
          isLoading: !isHome,
        };
      })
    );
  };

  // Tab Navigation: Forward
  const handleGoForward = () => {
    setTabs((prevTabs) =>
      prevTabs.map((tab) => {
        if (tab.id !== activeTabId || tab.historyIndex >= tab.history.length - 1) return tab;
        const newIndex = tab.historyIndex + 1;
        const targetUrl = tab.history[newIndex];
        const isHome = targetUrl === 'vortex://home' || targetUrl === 'vortex://newtab';

        return {
          ...tab,
          url: targetUrl,
          title: isHome ? 'New Tab' : targetUrl,
          favicon: isHome ? '' : getFaviconUrl(targetUrl),
          historyIndex: newIndex,
          isLoading: !isHome,
        };
      })
    );
  };

  // Tab Navigation: Reload
  const handleReload = () => {
    setTabs((prevTabs) =>
      prevTabs.map((tab) => {
        if (tab.id !== activeTabId) return tab;
        return {
          ...tab,
          isLoading: true,
        };
      })
    );
    if (activeTab.url === 'vortex://home') {
      setTimeout(() => {
        setTabs((prev) =>
          prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: false } : t))
        );
      }, 300);
    }
  };

  // Tab Navigation: Home
  const handleGoHome = () => {
    handleNavigate('vortex://home');
  };

  // Tab Management: New Tab
  const handleNewTab = () => {
    const newId = `tab-${Date.now()}`;
    const newTab: Tab = {
      id: newId,
      title: 'New Tab',
      url: 'vortex://home',
      favicon: '',
      history: ['vortex://home'],
      historyIndex: 0,
      isLoading: false,
      error: null,
      blockedTrackers: 0,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newId);
  };

  // Tab Management: Close Tab
  const handleCloseTab = (idToClose: string) => {
    setTabs((prev) => {
      const filtered = prev.filter((t) => t.id !== idToClose);

      if (filtered.length === 0) {
        const fallbackTab: Tab = {
          id: `tab-${Date.now()}`,
          title: 'New Tab',
          url: 'vortex://home',
          favicon: '',
          history: ['vortex://home'],
          historyIndex: 0,
          isLoading: false,
          error: null,
          blockedTrackers: 0,
        };
        setActiveTabId(fallbackTab.id);
        return [fallbackTab];
      }

      if (activeTabId === idToClose) {
        const closedIndex = prev.findIndex((t) => t.id === idToClose);
        const nextIndex = Math.min(closedIndex, filtered.length - 1);
        setActiveTabId(filtered[nextIndex].id);
      }

      return filtered;
    });
  };

  // Update metadata for a tab
  const handleUpdateTabMetadata = useCallback(
    (tabId: string, metadata: { title?: string; favicon?: string; blockedCount?: number }) => {
      setTabs((prev) =>
        prev.map((t) => {
          if (t.id !== tabId) return t;
          return {
            ...t,
            title: metadata.title || t.title,
            favicon: metadata.favicon !== undefined ? metadata.favicon : t.favicon,
            blockedTrackers: metadata.blockedCount !== undefined ? metadata.blockedCount : t.blockedTrackers,
            isLoading: false,
          };
        })
      );

      if (metadata.title) {
        setHistory((prev) =>
          prev.map((h) => (h.url === activeTab.url ? { ...h, title: metadata.title || h.title } : h))
        );
      }
    },
    [activeTab.url]
  );

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCmdOrCtrl = e.metaKey || e.ctrlKey;
      if (isCmdOrCtrl && e.key.toLowerCase() === 't') {
        e.preventDefault();
        handleNewTab();
      } else if (isCmdOrCtrl && e.key.toLowerCase() === 'w') {
        e.preventDefault();
        handleCloseTab(activeTabId);
      } else if (isCmdOrCtrl && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleReload();
      } else if (isCmdOrCtrl && e.key.toLowerCase() === 'h') {
        e.preventDefault();
        setIsHistoryOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTabId]);

  const canGoBack = activeTab.historyIndex > 0;
  const canGoForward = activeTab.historyIndex < activeTab.history.length - 1;
  const isHomePage = activeTab.url === 'vortex://home' || activeTab.url === 'vortex://newtab';

  return (
    <div className="flex flex-col w-screen h-screen bg-[#070512] text-slate-100 overflow-hidden font-sans select-none">
      {/* 1. Browser Tab Bar (At the very top) */}
      <TabBar
        tabs={tabs}
        activeTabId={activeTabId}
        onSelectTab={setActiveTabId}
        onCloseTab={handleCloseTab}
        onNewTab={handleNewTab}
      />

      {/* 2. Navigation / Address Bar (Takes up whole width, symbol removed, tiny bookmark dropdown list under bookmark button) */}
      <Toolbar
        activeTab={activeTab}
        canGoBack={canGoBack}
        canGoForward={canGoForward}
        isBookmarked={isCurrentBookmarked}
        shieldConfig={shieldConfig}
        selectedSearchEngine={selectedSearchEngine}
        username={userProfile.username}
        bookmarks={bookmarks}
        onNavigate={handleNavigate}
        onGoBack={handleGoBack}
        onGoForward={handleGoForward}
        onReload={handleReload}
        onGoHome={handleGoHome}
        onToggleBookmark={handleToggleBookmark}
        onRemoveBookmark={handleRemoveBookmark}
        onToggleShield={handleToggleShield}
        onOpenShieldPopup={() => setIsShieldPopupOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* 3. Active Tab Content Area */}
      <main className="flex-1 relative overflow-hidden bg-[#070512]">
        {isHomePage ? (
          <HomePage
            username={userProfile.username}
            selectedSearchEngine={selectedSearchEngine}
            quickLinks={quickLinks}
            shieldEnabled={shieldConfig.enabled}
            onSelectSearchEngine={handleSelectSearchEngine}
            onNavigate={handleNavigate}
            onOpenAddQuickLink={() => {
              setEditingQuickLink(null);
              setIsAddQuickLinkOpen(true);
            }}
            onEditQuickLink={handleEditQuickLink}
            onDeleteQuickLink={handleDeleteQuickLink}
          />
        ) : (
          <WebFrame
            tab={activeTab}
            shieldConfig={shieldConfig}
            selectedSearchEngine={selectedSearchEngine}
            onUpdateMetadata={handleUpdateTabMetadata}
            onNavigate={handleNavigate}
            onReload={handleReload}
          />
        )}
      </main>

      {/* First Launch Welcome Modal */}
      <WelcomeModal
        isOpen={isWelcomeModalOpen}
        onComplete={handleWelcomeComplete}
      />

      {/* Add / Edit Quick Link Modal */}
      <AddQuickLinkModal
        isOpen={isAddQuickLinkOpen}
        initialLink={editingQuickLink}
        onClose={() => {
          setIsAddQuickLinkOpen(false);
          setEditingQuickLink(null);
        }}
        onSave={handleSaveQuickLink}
      />

      {/* Browsing History Modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        history={history}
        onClose={() => setIsHistoryOpen(false)}
        onNavigate={handleNavigate}
        onDeleteEntry={handleDeleteHistoryEntry}
        onClearAllHistory={handleClearHistory}
      />

      {/* Security Shield Flyout */}
      <SecurityShieldPopover
        isOpen={isShieldPopupOpen}
        config={shieldConfig}
        currentHost={!isHomePage ? new URL(activeTab.url).hostname : undefined}
        onClose={() => setIsShieldPopupOpen(false)}
        onToggleShield={handleToggleShield}
        onUpdateConfig={handleUpdateShieldConfig}
      />
    </div>
  );
}
