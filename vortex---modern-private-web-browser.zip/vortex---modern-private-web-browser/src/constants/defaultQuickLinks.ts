import { QuickLink } from '../types/browser';

export const DEFAULT_QUICK_LINKS: QuickLink[] = [
  {
    id: 'tiktok',
    title: 'TikTok',
    url: 'https://www.tiktok.com',
    favicon: 'https://www.google.com/s2/favicons?domain=tiktok.com&sz=128',
    isCustom: false,
  },
  {
    id: 'discord',
    title: 'Discord',
    url: 'https://discord.com',
    favicon: 'https://www.google.com/s2/favicons?domain=discord.com&sz=128',
    isCustom: false,
  },
  {
    id: 'github',
    title: 'GitHub',
    url: 'https://github.com',
    favicon: 'https://www.google.com/s2/favicons?domain=github.com&sz=128',
    isCustom: false,
  },
  {
    id: 'spotify',
    title: 'Spotify',
    url: 'https://open.spotify.com',
    favicon: 'https://www.google.com/s2/favicons?domain=spotify.com&sz=128',
    isCustom: false,
  },
  {
    id: 'youtube',
    title: 'YouTube',
    url: 'https://www.youtube.com',
    favicon: 'https://www.google.com/s2/favicons?domain=youtube.com&sz=128',
    isCustom: false,
  },
];
