import { SearchEngine } from '../types/browser';

export const SEARCH_ENGINES: Record<string, SearchEngine> = {
  duckduckgo: {
    id: 'duckduckgo',
    name: 'DuckDuckGo',
    queryUrl: 'https://duckduckgo.com/?q=',
    homeUrl: 'https://duckduckgo.com',
    icon: 'https://duckduckgo.com/favicon.ico',
    placeholder: 'Search DuckDuckGo or enter URL...',
  },
  google: {
    id: 'google',
    name: 'Google',
    queryUrl: 'https://www.google.com/search?q=',
    homeUrl: 'https://www.google.com',
    icon: 'https://www.google.com/favicon.ico',
    placeholder: 'Search Google or enter URL...',
  },
  bing: {
    id: 'bing',
    name: 'Bing',
    queryUrl: 'https://www.bing.com/search?q=',
    homeUrl: 'https://www.bing.com',
    icon: 'https://www.bing.com/favicon.ico',
    placeholder: 'Search Bing or enter URL...',
  },
  brave: {
    id: 'brave',
    name: 'Brave Search',
    queryUrl: 'https://search.brave.com/search?q=',
    homeUrl: 'https://search.brave.com',
    icon: 'https://brave.com/static-assets/images/brave-favicon.png',
    placeholder: 'Search Brave or enter URL...',
  },
};

export const DEFAULT_SEARCH_ENGINE = 'duckduckgo';
