export type SearchEngineId = 'google' | 'bing' | 'duckduckgo' | 'brave';

export interface SearchEngine {
  id: SearchEngineId;
  name: string;
  queryUrl: string;
  icon: string;
  homeUrl: string;
  placeholder: string;
}

export interface Tab {
  id: string;
  title: string;
  url: string;
  favicon: string;
  history: string[];
  historyIndex: number;
  isLoading: boolean;
  error: string | null;
  blockedTrackers: number;
}

export interface QuickLink {
  id: string;
  title: string;
  url: string;
  favicon: string;
  isCustom?: boolean;
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  favicon: string;
  createdAt: number;
}

export interface HistoryEntry {
  id: string;
  title: string;
  url: string;
  favicon: string;
  visitedAt: number;
}

export interface SecurityShieldConfig {
  enabled: boolean;
  blockAds: boolean;
  blockTrackers: boolean;
  blockPopups: boolean;
  preventFingerprinting: boolean;
  totalBlockedCount: number;
}

export interface UserProfile {
  username: string;
  hasCompletedOnboarding: boolean;
  selectedSearchEngine: SearchEngineId;
  showBookmarkBar: boolean;
  themeAccent: string;
}
