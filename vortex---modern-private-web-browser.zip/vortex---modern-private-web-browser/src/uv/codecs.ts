// Ultraviolet Codecs
export const none = {
  encode: (str: string) => str,
  decode: (str: string) => str,
};

export const plain = {
  encode(str: string) {
    if (!str) return str;
    return encodeURIComponent(str);
  },
  decode(str: string) {
    if (!str) return str;
    try {
      return decodeURIComponent(str);
    } catch {
      return str;
    }
  },
};

export const xor = {
  encode(str: string) {
    if (!str) return str;
    let result = '';
    const len = str.length;
    for (let i = 0; i < len; i++) {
      const char = str[i];
      result += i % 2 ? String.fromCharCode(char.charCodeAt(0) ^ 2) : char;
    }
    return encodeURIComponent(result);
  },
  decode(str: string) {
    if (!str) return str;
    let decoded = str;
    try {
      decoded = decodeURIComponent(str);
    } catch {
      decoded = str;
    }
    let result = '';
    const len = decoded.length;
    for (let i = 0; i < len; i++) {
      const char = decoded[i];
      result += i % 2 ? String.fromCharCode(char.charCodeAt(0) ^ 2) : char;
    }
    return result;
  },
};

export const base64 = {
  encode(str: string) {
    if (!str) return str;
    return btoa(encodeURIComponent(str.toString()));
  },
  decode(str: string) {
    if (!str) return str;
    try {
      return decodeURIComponent(atob(str.toString()));
    } catch {
      return atob(str.toString());
    }
  },
};

export const codecs = {
  none,
  plain,
  xor,
  base64,
};

export default codecs;
