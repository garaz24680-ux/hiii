import { xor } from './codecs';
import { uvConfig } from './uv.config';

/**
 * Ultraviolet Browser Engine Helper
 */
export class UVEngine {
  static encode(url: string): string {
    return xor.encode(url);
  }

  static decode(encoded: string): string {
    return xor.decode(encoded);
  }

  static rewriteUrl(url: string, prefix = uvConfig.prefix): string {
    if (!url) return '';
    if (url.startsWith('vortex://') || url.startsWith('about:')) return url;
    if (url.startsWith(prefix)) return url;
    return `${prefix}${xor.encode(url)}`;
  }

  static extractActualUrl(proxiedUrl: string, prefix = uvConfig.prefix): string {
    if (!proxiedUrl) return '';
    if (proxiedUrl.startsWith(prefix)) {
      const encoded = proxiedUrl.slice(prefix.length);
      return xor.decode(encoded);
    }
    return proxiedUrl;
  }
}

export default UVEngine;
