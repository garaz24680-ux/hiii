import { xor } from './codecs';

export interface UVConfigType {
  prefix: string;
  encodeUrl: (url: string) => string;
  decodeUrl: (url: string) => string;
  handler: string;
  client: string;
  bundle: string;
  config: string;
  sw: string;
}

export const uvConfig: UVConfigType = {
  prefix: '/service/',
  encodeUrl: xor.encode,
  decodeUrl: xor.decode,
  handler: '/uv/uv.handler.js',
  client: '/uv/uv.client.js',
  bundle: '/uv/uv.bundle.js',
  config: '/uv/uv.config.js',
  sw: '/uv/uv.sw.js',
};

export default uvConfig;
